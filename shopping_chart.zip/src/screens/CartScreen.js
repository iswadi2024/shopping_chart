import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useCart } from '../context/CartContext';
import CartItem from '../components/CartItem';
import ConfirmDialog from '../components/ConfirmDialog';

// ──────────────────────────────────────────────
// CartScreen — Features 1, 3, 5
//
// Shows all items in the shopping cart, the total quantity
// (Feature 3), the total price, and a checkout button.
//
// Two dialogs (Feature 1):
//   • Checkout dialog — confirms the order and clears the cart
//   • Remove dialog   — confirms before removing an item
// ──────────────────────────────────────────────

const CartScreen = () => {
  const {
    items,
    removeFromCart,
    clearCart,
    totalQuantity,
    totalPrice,
  } = useCart();

  // ── Dialog state (Feature 1) ──
  const [checkoutDialog, setCheckoutDialog] = useState(false);
  const [removeTarget, setRemoveTarget] = useState(null);

  const handleRemoveRequest = (item) => {
    setRemoveTarget(item);
  };

  const confirmRemove = () => {
    if (removeTarget) {
      removeFromCart(removeTarget.id);
    }
    setRemoveTarget(null);
  };

  const confirmCheckout = () => {
    setCheckoutDialog(false);
    clearCart();
  };

  const formatPrice = (price) => `$${price.toFixed(2)}`;

  // ── Empty state ──
  if (items.length === 0) {
    return (
      <View style={styles.container}>
        <View style={styles.emptyState}>
          <Ionicons name="cart-outline" size={64} color="#ddd" />
          <Text style={styles.emptyTitle}>Your cart is empty</Text>
          <Text style={styles.emptySubtitle}>
            Browse products and add items to get started.
          </Text>
        </View>

        {/* Remove dialog should still render even when cart empties
            (e.g., user removed the last item) */}
        <ConfirmDialog
          visible={removeTarget !== null}
          title="Remove Item"
          message={`Remove "${removeTarget?.name}" from your cart?`}
          confirmLabel="Remove"
          confirmColor="#e74c3c"
          onConfirm={confirmRemove}
          onCancel={() => setRemoveTarget(null)}
        />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Cart item list */}
      <FlatList
        data={items}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <CartItem item={item} onRemoveRequest={handleRemoveRequest} />
        )}
        contentContainerStyle={styles.list}
      />

      {/* ── Summary section ── */}
      <View style={styles.summary}>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Items</Text>
          <Text style={styles.summaryValue}>{items.length}</Text>
        </View>

        {/* Total quantity — Feature 3 */}
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Total Quantity</Text>
          <View style={styles.quantityBadge}>
            <Text style={styles.quantityBadgeText}>{totalQuantity}</Text>
          </View>
        </View>

        <View style={styles.divider} />

        <View style={styles.summaryRow}>
          <Text style={styles.totalLabel}>Total</Text>
          <Text style={styles.totalValue}>{formatPrice(totalPrice)}</Text>
        </View>

        {/* Checkout button — opens dialog (Feature 1) */}
        <TouchableOpacity
          style={styles.checkoutButton}
          onPress={() => setCheckoutDialog(true)}
          activeOpacity={0.8}
        >
          <Ionicons name="card-outline" size={22} color="#fff" />
          <Text style={styles.checkoutText}>Checkout</Text>
        </TouchableOpacity>
      </View>

      {/* ── Checkout confirmation dialog (Feature 1) ── */}
      <ConfirmDialog
        visible={checkoutDialog}
        title="Confirm Checkout"
        message={`You have ${totalQuantity} item(s) totaling ${formatPrice(
          totalPrice
        )}. Proceed with checkout?`}
        confirmLabel="Checkout"
        confirmColor="#4CAF50"
        onConfirm={confirmCheckout}
        onCancel={() => setCheckoutDialog(false)}
      />

      {/* ── Remove confirmation dialog (Feature 1) ── */}
      <ConfirmDialog
        visible={removeTarget !== null}
        title="Remove Item"
        message={`Remove "${removeTarget?.name}" from your cart?`}
        confirmLabel="Remove"
        confirmColor="#e74c3c"
        onConfirm={confirmRemove}
        onCancel={() => setRemoveTarget(null)}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  list: {
    paddingVertical: 8,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#999',
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 14,
    color: '#bbb',
    marginTop: 8,
    textAlign: 'center',
    marginHorizontal: 40,
  },
  summary: {
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#E8E8E8',
    paddingHorizontal: 20,
    paddingVertical: 16,
    paddingBottom: 30,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  summaryLabel: {
    fontSize: 14,
    color: '#666',
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  quantityBadge: {
    backgroundColor: '#4A90D9',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 4,
    minWidth: 36,
    alignItems: 'center',
  },
  quantityBadgeText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '700',
  },
  divider: {
    height: 1,
    backgroundColor: '#E8E8E8',
    marginVertical: 4,
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: '700',
    color: '#333',
  },
  totalValue: {
    fontSize: 22,
    fontWeight: '700',
    color: '#4A90D9',
  },
  checkoutButton: {
    flexDirection: 'row',
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 12,
  },
  checkoutText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '700',
    marginLeft: 8,
  },
});

export default CartScreen;
