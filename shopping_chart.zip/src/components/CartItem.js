import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  StyleSheet,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useCart } from '../context/CartContext';

// ──────────────────────────────────────────────
// CartItem — Feature 1 (remove dialog) + Feature 5 (quantity by multiples)
//
// Each row in the shopping cart. Shows the product, its line total,
// and quantity controls:
//   • − / + buttons that move by the product's `step` (multiples)
//   • A directly-editable TextInput that rounds to the nearest valid multiple
//   • A trash button that opens a confirmation dialog before removing
// ──────────────────────────────────────────────

const CartItem = ({ item, onRemoveRequest }) => {
  const { incrementQuantity, decrementQuantity, setExactQuantity } = useCart();
  const [editValue, setEditValue] = useState(String(item.quantity));

  // Keep local input in sync when the cart state changes elsewhere
  React.useEffect(() => {
    setEditValue(String(item.quantity));
  }, [item.quantity]);

  const handleDecrement = () => {
    // If removing one more step would drop below the minimum,
    // ask the user if they want to remove the item entirely.
    if (item.quantity - item.step < item.step) {
      onRemoveRequest(item);
    } else {
      decrementQuantity(item.id);
    }
  };

  const handleIncrement = () => {
    incrementQuantity(item.id);
  };

  const handleBlur = () => {
    // Validate and round the typed value to a valid multiple of step
    let value = parseInt(editValue, 10);
    if (isNaN(value) || value < item.step) {
      value = item.step;
    } else {
      // Round up to the nearest multiple of step
      value = Math.ceil(value / item.step) * item.step;
    }
    setExactQuantity(item.id, value);
    setEditValue(String(value));
  };

  const formatPrice = (price) => `$${price.toFixed(2)}`;

  return (
    <View style={styles.card}>
      <View style={styles.imageContainer}>
        <Text style={styles.image}>{item.image}</Text>
      </View>

      <View style={styles.info}>
        <Text style={styles.name}>{item.name}</Text>
        <Text style={styles.pricePerUnit}>
          {formatPrice(item.price)} each
          {item.step > 1 && ` · sold in ${item.step}s`}
        </Text>
        <Text style={styles.lineTotal}>{formatPrice(item.price * item.quantity)}</Text>
      </View>

      {/* ── Quantity controls (Feature 5) ── */}
      <View style={styles.quantitySection}>
        <View style={styles.quantityRow}>
          <TouchableOpacity
            style={styles.qtyButton}
            onPress={handleDecrement}
            activeOpacity={0.6}
          >
            <Ionicons name="remove" size={18} color="#4A90D9" />
          </TouchableOpacity>

          <TextInput
            style={styles.qtyInput}
            value={editValue}
            onChangeText={setEditValue}
            onBlur={handleBlur}
            keyboardType="numeric"
            returnKeyType="done"
            blurOnSubmit
          />

          <TouchableOpacity
            style={styles.qtyButton}
            onPress={handleIncrement}
            activeOpacity={0.6}
          >
            <Ionicons name="add" size={18} color="#4A90D9" />
          </TouchableOpacity>
        </View>

        <Text style={styles.stepHint}>
          {item.step > 1 ? `in ${item.step}s` : ''}
        </Text>
      </View>

      {/* ── Remove button (opens dialog — Feature 1) ── */}
      <TouchableOpacity
        style={styles.removeButton}
        onPress={() => onRemoveRequest(item)}
        activeOpacity={0.6}
      >
        <Ionicons name="trash-outline" size={20} color="#e74c3c" />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 14,
    marginHorizontal: 16,
    marginVertical: 6,
    padding: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  imageContainer: {
    width: 56,
    height: 56,
    borderRadius: 10,
    backgroundColor: '#F8F9FA',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  image: {
    fontSize: 28,
  },
  info: {
    flex: 1,
  },
  name: {
    fontSize: 14,
    fontWeight: '700',
    color: '#333',
    marginBottom: 2,
  },
  pricePerUnit: {
    fontSize: 11,
    color: '#999',
    marginBottom: 4,
  },
  lineTotal: {
    fontSize: 16,
    fontWeight: '700',
    color: '#4A90D9',
  },
  quantitySection: {
    alignItems: 'center',
    marginHorizontal: 8,
  },
  quantityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8F9FA',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#E8E8E8',
  },
  qtyButton: {
    width: 32,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
  },
  qtyInput: {
    width: 44,
    height: 36,
    textAlign: 'center',
    fontSize: 15,
    fontWeight: '700',
    color: '#333',
    borderTopWidth: 0,
    borderBottomWidth: 0,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: '#E8E8E8',
    padding: 0,
  },
  stepHint: {
    fontSize: 10,
    color: '#bbb',
    marginTop: 2,
    height: 14,
  },
  removeButton: {
    padding: 8,
  },
});

export default CartItem;
