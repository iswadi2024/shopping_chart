import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useCart } from '../context/CartContext';

// ──────────────────────────────────────────────
// ProductCard
//
// Displays a single product with its emoji "image", name,
// price, step info, and an "Add to Cart" button.
// Pressing the button calls addToCart from CartContext,
// which triggers the toast notification (Feature 2) and
// increments by the product's step (Feature 5).
// ──────────────────────────────────────────────

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();

  const formatPrice = (price) => `$${price.toFixed(2)}`;

  return (
    <View style={styles.card}>
      <View style={styles.imageContainer}>
        <Text style={styles.image}>{product.image}</Text>
      </View>

      <View style={styles.info}>
        <Text style={styles.name}>{product.name}</Text>
        <Text style={styles.description} numberOfLines={2}>
          {product.description}
        </Text>

        <View style={styles.bottomRow}>
          <View>
            <Text style={styles.price}>{formatPrice(product.price)}</Text>
            {product.step > 1 && (
              <Text style={styles.stepBadge}>Min: {product.step} pcs</Text>
            )}
          </View>

          <TouchableOpacity
            style={styles.addButton}
            onPress={() => addToCart(product)}
            activeOpacity={0.7}
          >
            <Ionicons name="add" size={20} color="#fff" />
            <Text style={styles.addText}>Add</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 14,
    marginHorizontal: 16,
    marginVertical: 6,
    padding: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  imageContainer: {
    width: 64,
    height: 64,
    borderRadius: 12,
    backgroundColor: '#F8F9FA',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  image: {
    fontSize: 32,
  },
  info: {
    flex: 1,
  },
  name: {
    fontSize: 15,
    fontWeight: '700',
    color: '#333',
    marginBottom: 4,
  },
  description: {
    fontSize: 12,
    color: '#999',
    marginBottom: 8,
  },
  bottomRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  price: {
    fontSize: 17,
    fontWeight: '700',
    color: '#4A90D9',
  },
  stepBadge: {
    fontSize: 11,
    color: '#F5A623',
    fontWeight: '600',
    marginTop: 2,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#4A90D9',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
  },
  addText: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '700',
    marginLeft: 2,
  },
});

export default ProductCard;
