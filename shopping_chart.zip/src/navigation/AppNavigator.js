import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { useCart } from '../context/CartContext';
import HomeScreen from '../screens/HomeScreen';
import CartScreen from '../screens/CartScreen';
import Toast from '../components/Toast';

const Tab = createBottomTabNavigator();

// ──────────────────────────────────────────────
// AppNavigator
//
// Two-tab bottom navigator:
//   "Shop"  — HomeScreen (search + product list)
//   "Cart"  — CartScreen (cart items + checkout)
//
// The Cart tab shows a badge with totalQuantity (Feature 3),
// visible on the tab bar icon at all times.
//
// The Toast component is rendered here so it overlays every
// screen (Feature 2). It reads its state from CartContext.
// ──────────────────────────────────────────────

const CartBadge = ({ count }) => {
  if (count === 0) return null;
  return (
    <View style={styles.badge}>
      <Text style={styles.badgeText}>{count > 99 ? '99+' : count}</Text>
    </View>
  );
};

const AppNavigator = () => {
  const { totalQuantity, toast } = useCart();

  return (
    <NavigationContainer>
      {/* Global toast — Feature 2 */}
      <Toast message={toast.message} visible={toast.visible} />

      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerStyle: { backgroundColor: '#4A90D9' },
          headerTitleStyle: { color: '#fff', fontWeight: '700', fontSize: 18 },
          headerTintColor: '#fff',
          tabBarActiveTintColor: '#4A90D9',
          tabBarInactiveTintColor: '#999',
          tabBarStyle: {
            backgroundColor: '#fff',
            borderTopColor: '#E8E8E8',
            paddingBottom: 4,
          },
          tabBarIcon: ({ focused, color, size }) => {
            if (route.name === 'Shop') {
              return (
                <Ionicons
                  name={focused ? 'storefront' : 'storefront-outline'}
                  size={size}
                  color={color}
                />
              );
            }
            if (route.name === 'Cart') {
              return (
                <View>
                  <Ionicons
                    name={focused ? 'cart' : 'cart-outline'}
                    size={size}
                    color={color}
                  />
                  {/* Cart badge — Feature 3 */}
                  <CartBadge count={totalQuantity} />
                </View>
              );
            }
          },
        })}
      >
        <Tab.Screen
          name="Shop"
          component={HomeScreen}
          options={{ title: 'Shop' }}
        />
        <Tab.Screen
          name="Cart"
          component={CartScreen}
          options={{
            title: 'Cart',
            tabBarLabel: 'Cart',
            headerTitle: 'My Cart',
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  badge: {
    position: 'absolute',
    top: -4,
    right: -8,
    backgroundColor: '#e74c3c',
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: '700',
  },
});

export default AppNavigator;
