import React, { createContext, useContext, useState, useCallback } from 'react';

// ──────────────────────────────────────────────
// CartContext — central state for the shopping cart.
//
// Responsibilities:
//   • Hold the cart item list
//   • Add / remove items
//   • Update quantities (Feature 5 — by multiples / step)
//   • Compute total quantity (Feature 3) and total price
//  • Manage toast notifications (Feature 2)
// ──────────────────────────────────────────────

const CartContext = createContext();

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
  const [items, setItems] = useState([]);
  const [toast, setToast] = useState({ message: '', visible: false });

  // ── Toast helper (Feature 2) ──────────────────
  const showToast = useCallback((message) => {
    setToast({ message, visible: true });
    // Auto-dismiss after 2.5 seconds
    setTimeout(() => {
      setToast((prev) => ({ ...prev, visible: false }));
    }, 2500);
  }, []);

  // ── Add to cart ──────────────────────────────
  // If the product already exists in the cart, increase its quantity
  // by the product's `step`. Otherwise insert it with quantity = step.
  const addToCart = useCallback(
    (product) => {
      setItems((prevItems) => {
        const existing = prevItems.find((item) => item.id === product.id);
        if (existing) {
          // ── Feature 5 fix: increment by step, not always 1 ──
          return prevItems.map((item) =>
            item.id === product.id
              ? { ...item, quantity: item.quantity + product.step }
              : item
          );
        }
        return [...prevItems, { ...product, quantity: product.step }];
      });
      showToast(`${product.name} added to cart`);
    },
    [showToast]
  );

  // ── Remove item entirely ──────────────────────
  const removeFromCart = useCallback((productId) => {
    setItems((prevItems) => prevItems.filter((item) => item.id !== productId));
  }, []);

  // ── Increment quantity by step (Feature 5) ──
  const incrementQuantity = useCallback((productId) => {
    setItems((prevItems) =>
      prevItems.map((item) =>
        item.id === productId
          ? { ...item, quantity: item.quantity + item.step }
          : item
      )
    );
  }, []);

  // ── Decrement quantity by step (Feature 5) ──
  // Never goes below one step's worth — if it would, the item
  // should be removed entirely (handled by the caller).
  const decrementQuantity = useCallback((productId) => {
    setItems((prevItems) =>
      prevItems.map((item) => {
        if (item.id === productId) {
          const newQty = item.quantity - item.step;
          return { ...item, quantity: Math.max(item.step, newQty) };
        }
        return item;
      })
    );
  }, []);

  // ── Set exact quantity via direct input (Feature 5) ──
  // Validates that the entered value is a positive multiple of step.
  // If not, rounds up to the nearest valid multiple.
  const setExactQuantity = useCallback((productId, rawValue) => {
    setItems((prevItems) =>
      prevItems.map((item) => {
        if (item.id === productId) {
          let value = parseInt(rawValue, 10);
          if (isNaN(value) || value < item.step) {
            value = item.step;
          }
          // Round to nearest multiple of step
          value = Math.ceil(value / item.step) * item.step;
          return { ...item, quantity: value };
        }
        return item;
      })
    );
  }, []);

  // ── Clear the entire cart ────────────────────
  const clearCart = useCallback(() => {
    setItems([]);
  }, []);

  // ── Derived values (Feature 3) ───────────────
  // Total quantity = sum of every item's quantity
  const totalQuantity = items.reduce((sum, item) => sum + item.quantity, 0);

  // Total price = sum of (price × quantity) for each item
  const totalPrice = items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const value = {
    items,
    addToCart,
    removeFromCart,
    incrementQuantity,
    decrementQuantity,
    setExactQuantity,
    clearCart,
    totalQuantity,
    totalPrice,
    toast,
    showToast,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};
