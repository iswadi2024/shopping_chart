import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { CartProvider } from './src/context/CartContext';
import AppNavigator from './src/navigation/AppNavigator';

// ──────────────────────────────────────────────
// App.js — Entry point
//
// Wraps everything in CartProvider so the shared cart state
// is available throughout the app (HomeScreen, CartScreen,
// CartBadge, Toast, etc.).
// ──────────────────────────────────────────────

export default function App() {
  return (
    <SafeAreaProvider>
      <CartProvider>
        <AppNavigator />
        <StatusBar style="light" />
      </CartProvider>
    </SafeAreaProvider>
  );
}
