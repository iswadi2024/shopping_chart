# Shopping Cart App — React Native Analysis

A React Native (Expo) shopping cart application implementing five key features. This document analyzes each feature, its implementation, and the overall architecture.

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [Feature 1 — Dialog Window for Checkout & Remove](#feature-1--dialog-window-for-checkout--remove)
3. [Feature 2 — Add-to-Cart Notifications](#feature-2--add-to-cart-notifications)
4. [Feature 3 — Total Quantity Counter](#feature-3--total-quantity-counter)
5. [Feature 4 — Product Search Box](#feature-4--product-search-box)
6. [Feature 5 — Fix Quantity Couldn't Update by Multiples](#feature-5--fix-quantity-couldnt-update-by-multiples)
7. [How to Run](#how-to-run)

---

## 1. Architecture Overview

### Project Structure

```
├── App.js                          # Entry point — wraps app in CartProvider
├── app.json                        # Expo configuration
├── babel.config.js                 # Babel preset for Expo
├── package.json                    # Dependencies & scripts
├── src/
│   ├── data/
│   │   └── products.js             # Sample product catalog (12 products)
│   ├── context/
│   │   └── CartContext.js          # Central cart state via React Context
│   ├── components/
│   │   ├── Toast.js                # Animated notification (Feature 2)
│   │   ├── ConfirmDialog.js        # Reusable modal dialog (Feature 1)
│   │   ├── SearchBox.js            # Search input (Feature 4)
│   │   ├── ProductCard.js          # Product row with Add button
│   │   └── CartItem.js             # Cart row with quantity controls (Feature 5)
│   ├── screens/
│   │   ├── HomeScreen.js           # Product list + search + category filter
│   │   └── CartScreen.js           # Cart list + totals + checkout dialog
│   └── navigation/
│       └── AppNavigator.js         # Bottom tab navigator with cart badge
```

### State Management

The app uses **React Context API** (`CartContext`) as a single source of truth for cart state. This avoids prop drilling and keeps all cart logic in one place:

| State / Derived value | Type | Description |
|---|---|---|
| `items` | `Array<Product>` | Cart items with quantity |
| `totalQuantity` | `number` | Sum of all item quantities (Feature 3) |
| `totalPrice` | `number` | Sum of price × quantity |
| `toast` | `{ message, visible }` | Notification state (Feature 2) |

| Action | Description |
|---|---|
| `addToCart(product)` | Adds product, increments by `step` if already in cart |
| `removeFromCart(id)` | Removes item by id |
| `incrementQuantity(id)` | Adds one `step` to the quantity (Feature 5) |
| `decrementQuantity(id)` | Subtracts one `step`, floor at minimum step |
| `setExactQuantity(id, value)` | Sets a typed quantity, rounds to valid multiple |
| `clearCart()` | Empties the cart (used after checkout) |
| `showToast(message)` | Triggers the toast notification |

### Navigation

Bottom tab navigator with two tabs:

- **Shop** — `HomeScreen` (search + product list)
- **Cart** — `CartScreen` (cart items + totals + checkout)

The Cart tab icon displays a red badge showing `totalQuantity`, making the total visible at all times from any screen.

---

## Feature 1 — Dialog Window for Checkout & Remove

### Requirement

When a user wants to checkout or remove an item from the shopping cart, a confirmation dialog should appear before the action is executed.

### Implementation

A single reusable component, `ConfirmDialog`, handles both scenarios. It's a React Native `Modal` with a semi-transparent overlay, a card body, and two buttons (Cancel / Confirm).

**File:** `src/components/ConfirmDialog.js`

```jsx
<ConfirmDialog
  visible={checkoutDialog}
  title="Confirm Checkout"
  message={`You have ${totalQuantity} item(s) totaling ${formatPrice(totalPrice)}. Proceed?`}
  confirmLabel="Checkout"
  confirmColor="#4CAF50"
  onConfirm={confirmCheckout}
  onCancel={() => setCheckoutDialog(false)}
/>
```

**Two use cases in `CartScreen.js`:**

| Use Case | Trigger | Dialog Title | Confirm Action |
|---|---|---|---|
| Checkout | Tapping "Checkout" button | "Confirm Checkout" | Calls `clearCart()` — simulates order completion |
| Remove item | Tapping trash icon on a cart row | "Remove Item" | Calls `removeFromCart(item.id)` |

The dialog is fully reusable — any screen can show it by passing `visible`, `title`, `message`, and callbacks. The confirm button color is customizable (`#4CAF50` for checkout, `#e74c3c` for destructive remove).

---

## Feature 2 — Add-to-Cart Notifications

### Requirement

When a user adds an item to the shopping cart, a notification should appear briefly to confirm the action.

### Implementation

**Files:** `src/components/Toast.js` + `CartContext.js`

The toast is an animated `View` positioned at the top of the screen. It uses `Animated.sequence` to:
1. Fade in (300ms)
2. Hold visible (1900ms)
3. Fade out (300ms)

The toast state lives in `CartContext` so it works from any screen. When `addToCart` is called, it triggers `showToast()`:

```js
const showToast = useCallback((message) => {
  setToast({ message, visible: true });
  setTimeout(() => {
    setToast((prev) => ({ ...prev, visible: false }));
  }, 2500);
}, []);

const addToCart = useCallback((product) => {
  // ... cart update logic ...
  showToast(`${product.name} added to cart`);
}, [showToast]);
```

The `Toast` component is rendered inside `AppNavigator` so it overlays every screen:

```jsx
<Toast message={toast.message} visible={toast.visible} />
```

Design choices:
- Green background (`#4CAF50`) with a checkmark icon for positive confirmation
- `pointerEvents="none"` so it doesn't block interaction while visible
- Auto-dismiss after 2.5 seconds — no user action needed

---

## Feature 3 — Total Quantity Counter

### Requirement

Display the total quantity of all items in the user's shopping cart.

### Implementation

The total is a **derived value** computed from the cart items array using `reduce`:

```js
// CartContext.js
const totalQuantity = items.reduce((sum, item) => sum + item.quantity, 0);
```

It's displayed in **two places**:

1. **Cart tab badge** (visible from any screen) — in `AppNavigator.js`:
   ```jsx
   <CartBadge count={totalQuantity} />
   ```
   Shows a red circle with the count next to the cart icon. Hides when count is 0.

2. **Cart summary section** (in `CartScreen.js`):
   ```jsx
   <View style={styles.summaryRow}>
     <Text>Total Quantity</Text>
     <View style={styles.quantityBadge}>
       <Text>{totalQuantity}</Text>
     </View>
   </View>
   ```

Because `totalQuantity` is derived from state (not stored separately), it's always accurate — no risk of the counter drifting out of sync with the actual items.

---

## Feature 4 — Product Search Box

### Requirement

Add a search box so users can find products more easily.

### Implementation

**Files:** `src/components/SearchBox.js` + `src/screens/HomeScreen.js`

`SearchBox` is a controlled `TextInput` with a magnifying glass icon and a clear (×) button that appears when text is entered. The parent `HomeScreen` holds the search query in state and filters the product list with `useMemo`:

```js
const filteredProducts = useMemo(() => {
  return PRODUCTS.filter((product) => {
    const query = searchQuery.toLowerCase().trim();
    return (
      query === '' ||
      product.name.toLowerCase().includes(query) ||
      product.description.toLowerCase().includes(query) ||
      product.category.toLowerCase().includes(query)
    );
  });
}, [searchQuery, activeCategory]);
```

Search behavior:
- Case-insensitive
- Matches product **name**, **description**, and **category**
- Works in combination with the category filter chips
- Shows "N products found" count
- Shows an empty-state message when no results match
- Clear button (×) resets the query instantly

---

## Feature 5 — Fix Quantity Couldn't Update by Multiples

### Requirement

Fix a bug where the quantity could only update by 1, ignoring the product's required purchase multiple (step). Products like "Eggs (Dozen)" with `step: 12` should only allow quantities of 12, 24, 36, etc.

### Root Cause Analysis

The original (buggy) pattern typically looks like this:

```js
// BUG: always adds 1 regardless of the product's step
const incrementQuantity = (itemId) => {
  setItems(items.map(item =>
    item.id === itemId
      ? { ...item, quantity: item.quantity + 1 }  // ← hardcoded +1
      : item
  ));
};
```

This means a product with `step: 6` would go 6 → 7 → 8 → 9... instead of 6 → 12 → 18 → 24. The quantity falls out of sync with the valid purchase multiple.

### Fix

**File:** `src/context/CartContext.js` + `src/components/CartItem.js`

Three changes were made:

#### 1. Increment / decrement respect the step

```js
const incrementQuantity = useCallback((productId) => {
  setItems((prevItems) =>
    prevItems.map((item) =>
      item.id === productId
        ? { ...item, quantity: item.quantity + item.step }  // ← +step, not +1
        : item
    )
  );
}, []);

const decrementQuantity = useCallback((productId) => {
  setItems((prevItems) =>
    prevItems.map((item) => {
      if (item.id === productId) {
        const newQty = item.quantity - item.step;  // ← -step, not -1
        return { ...item, quantity: Math.max(item.step, newQty) };
      }
      return item;
    })
  );
}, []);
```

#### 2. Adding to cart uses step as the initial quantity

```js
const addToCart = useCallback((product) => {
  setItems((prevItems) => {
    const existing = prevItems.find((item) => item.id === product.id);
    if (existing) {
      return prevItems.map((item) =>
        item.id === product.id
          ? { ...item, quantity: item.quantity + product.step }  // ← +step
          : item
      );
    }
    return [...prevItems, { ...product, quantity: product.step }];  // ← start at step
  });
}, [showToast]);
```

#### 3. Direct text input validates and rounds to a valid multiple

```js
const handleBlur = () => {
  let value = parseInt(editValue, 10);
  if (isNaN(value) || value < item.step) {
    value = item.step;
  } else {
    value = Math.ceil(value / item.step) * item.step;  // ← round up to multiple
  }
  setExactQuantity(item.id, value);
  setEditValue(String(value));
};
```

If a user types "15" for a product with `step: 6`, the value rounds up to 18 (the next valid multiple).

### Product Step Values

| Product | Step | Valid Quantities |
|---|---|---|
| Arabica Coffee Beans | 1 | 1, 2, 3, 4, ... |
| Spring Water (Pack of 6) | 6 | 6, 12, 18, 24, ... |
| Mixed Nuts (Pack of 4) | 4 | 4, 8, 12, 16, ... |
| Free-Range Eggs (Dozen) | 12 | 12, 24, 36, 48, ... |
| Butter Croissants (Pack of 4) | 4 | 4, 8, 12, 16, ... |

The `CartItem` component shows a "in 6s" hint below the quantity input when `step > 1`, so the user understands the constraint.

---

## How to Run

```bash
# Install dependencies
npm install

# Start the Expo dev server
npx expo start
```

Then scan the QR code with the Expo Go app (Android/iOS), or press `a` for Android emulator or `i` for iOS simulator.

### Dependencies

| Package | Purpose |
|---|---|
| expo | App framework & dev server |
| react / react-native | Core framework |
| @react-navigation/native + bottom-tabs | Tab navigation |
| react-native-screens / safe-area-context | Navigation prerequisites |
| @expo/vector-icons | Ionicons for UI icons |

---

## Summary

| Feature | Component(s) | Key File |
|---|---|---|
| 1. Checkout & remove dialogs | `ConfirmDialog` | `CartScreen.js` |
| 2. Add-to-cart notification | `Toast` | `CartContext.js`, `Toast.js` |
| 3. Total quantity counter | Derived `reduce` | `CartContext.js`, `AppNavigator.js` |
| 4. Product search box | `SearchBox` | `HomeScreen.js` |
| 5. Quantity update by multiples | `incrementQuantity` / `decrementQuantity` / `setExactQuantity` | `CartContext.js`, `CartItem.js` |
